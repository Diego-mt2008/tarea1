<?php
// Ajusta estos datos a tu instalación local de Laragon.
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'sistema_ventas');
define('DB_USER', 'root');
define('DB_PASS', ''); // Si root tiene contraseña, escríbela entre las comillas.
define('APP_NAME', 'Sistema de ventas e inventario');
date_default_timezone_set('America/Lima');

STOCKPRO - SISTEMA DE VENTAS E INVENTARIO
========================================
Versión de interfaz mejorada para PHP + MySQL + Laragon.

CREDENCIALES DE DEMOSTRACIÓN
----------------------------
Usuario: admin
Contraseña: 123

La contraseña 123 se usa únicamente por solicitud para prácticas locales. Es débil y no debe usarse en producción.

INSTALACIÓN EN LARAGON
----------------------
1. Descomprime la carpeta sistema_ventas dentro de C:\laragon\www\
2. Inicia Apache y MySQL con Laragon (Start All).
3. Abre HeidiSQL o phpMyAdmin.
4. Importa database/sistema_ventas.sql. El script crea la base sistema_ventas, las tablas y datos de demostración.
5. Revisa config/config.php:
   DB_HOST = 127.0.0.1
   DB_NAME = sistema_ventas
   DB_USER = root
   DB_PASS = '' (si root tiene contraseña, escríbela aquí).
6. Abre http://localhost/sistema_ventas/

MEJORAS DE ESTA VERSIÓN
-----------------------
- Interfaz reorganizada con panel lateral, indicadores y accesos rápidos.
- Formularios de productos, clientes, proveedores, categorías, unidades y usuarios en modales.
- Compras y ventas en modal con detalle de múltiples productos, cantidades, precio unitario, subtotal y total calculado en pantalla.
- SweetAlert2 para confirmaciones de operaciones, cambios de estado, cierre de sesión y mensajes de éxito/error.
- Validaciones de servidor, protección CSRF, consultas preparadas y transacciones para compras/ventas.
- Prevención de ventas con stock insuficiente y combinación de líneas duplicadas del mismo producto.
- Catálogo de productos en modo de solo lectura para vendedores.
- Reportes de inventario, stock bajo, historial de compras y ventas con filtros.
- Detalle de operación, movimientos de stock y auditoría.
- Stock de producto no se puede editar desde el formulario común; se actualiza con compras y ventas.

ROLES
-----
Administrador: gestiona catálogos, usuarios, compras, ventas, reportes, movimientos y auditoría.
Vendedor: registra ventas y consulta el catálogo de productos.

REQUISITOS DE CONEXIÓN
---------------------
La interfaz carga Bootstrap 5, Bootstrap Icons y SweetAlert2 desde CDN. Se requiere conexión a Internet para cargar estas bibliotecas, salvo que se descarguen y sirvan localmente.

NOTAS
-----
- El SQL está diseñado para instalar el proyecto desde cero. Haz una copia de seguridad si ya tienes una base con información que quieras conservar.
- Los datos de clientes/proveedores son ficticios para fines educativos.
- No se implementa recuperación de contraseña ni anulación de operaciones; no se muestran botones falsos para esas funciones.
- Antes de producción, cambia la clave inicial, configura HTTPS, usa una cuenta MySQL con permisos limitados y realiza pruebas de seguridad.

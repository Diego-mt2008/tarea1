CREATE DATABASE IF NOT EXISTS sistema_ventas
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_ventas;
CREATE TABLE usuarios (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  usuario VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  rol ENUM('admin','vendedor') NOT NULL DEFAULT 'vendedor',
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en DATETIME NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE categorias (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL UNIQUE,
  descripcion VARCHAR(255) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE unidades_medida (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(60) NOT NULL UNIQUE,
  abreviatura VARCHAR(15) NOT NULL UNIQUE,
  activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;
CREATE TABLE clientes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tipo_documento ENUM('DNI','RUC','CE','OTRO') NULL,
  numero_documento VARCHAR(20) NULL,
  nombre VARCHAR(160) NOT NULL,
  telefono VARCHAR(30) NULL,
  correo VARCHAR(120) NULL,
  direccion VARCHAR(255) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_cliente_nombre (nombre),
  UNIQUE KEY uq_cliente_documento (tipo_documento, numero_documento)
) ENGINE=InnoDB;
CREATE TABLE proveedores (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tipo_documento ENUM('DNI','RUC','CE','OTRO') NULL,
  numero_documento VARCHAR(20) NULL,
  nombre VARCHAR(160) NOT NULL,
  contacto VARCHAR(120) NULL,
  telefono VARCHAR(30) NULL,
  correo VARCHAR(120) NULL,
  direccion VARCHAR(255) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_proveedor_nombre (nombre),
  UNIQUE KEY uq_proveedor_documento (tipo_documento, numero_documento)
) ENGINE=InnoDB;
CREATE TABLE productos (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(50) NOT NULL UNIQUE,
  nombre VARCHAR(160) NOT NULL,
  descripcion VARCHAR(255) NULL,
  categoria_id BIGINT UNSIGNED NULL,
  unidad_id BIGINT UNSIGNED NOT NULL,
  precio_compra DECIMAL(12,2) NOT NULL DEFAULT 0,
  precio_venta DECIMAL(12,2) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  stock_minimo INT NOT NULL DEFAULT 5,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  FOREIGN KEY (unidad_id) REFERENCES unidades_medida(id),
  CONSTRAINT chk_producto_compra CHECK (precio_compra >= 0),
  CONSTRAINT chk_producto_venta CHECK (precio_venta >= 0),
  CONSTRAINT chk_producto_stock CHECK (stock >= 0),
  CONSTRAINT chk_producto_stock_min CHECK (stock_minimo >= 0),
  INDEX idx_producto_nombre (nombre)
) ENGINE=InnoDB;
CREATE TABLE compras (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  numero VARCHAR(30) NOT NULL UNIQUE,
  proveedor_id BIGINT UNSIGNED NOT NULL,
  usuario_id BIGINT UNSIGNED NOT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  estado ENUM('confirmada','anulada') NOT NULL DEFAULT 'confirmada',
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
  impuesto DECIMAL(12,2) NOT NULL DEFAULT 0,
  total DECIMAL(12,2) NOT NULL DEFAULT 0,
  observacion VARCHAR(500) NULL,
  anulada_por BIGINT UNSIGNED NULL,
  anulada_en DATETIME NULL,
  motivo_anulacion VARCHAR(255) NULL,
  FOREIGN KEY (proveedor_id) REFERENCES proveedores(id),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (anulada_por) REFERENCES usuarios(id),
  CONSTRAINT chk_compra_importes CHECK (subtotal >= 0 AND impuesto >= 0 AND total >= 0),
  INDEX idx_compra_fecha (fecha),
  INDEX idx_compra_estado (estado)
) ENGINE=InnoDB;
CREATE TABLE detalle_compra (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  compra_id BIGINT UNSIGNED NOT NULL,
  producto_id BIGINT UNSIGNED NOT NULL,
  cantidad INT NOT NULL,
  precio_unitario DECIMAL(12,2) NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (compra_id) REFERENCES compras(id),
  FOREIGN KEY (producto_id) REFERENCES productos(id),
  CONSTRAINT chk_det_compra_cantidad CHECK (cantidad > 0),
  CONSTRAINT chk_det_compra_precio CHECK (precio_unitario >= 0 AND subtotal >= 0),
  INDEX idx_det_compra_producto (producto_id)
) ENGINE=InnoDB;
CREATE TABLE ventas (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  numero VARCHAR(30) NOT NULL UNIQUE,
  cliente_id BIGINT UNSIGNED NULL,
  usuario_id BIGINT UNSIGNED NOT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  estado ENUM('confirmada','anulada') NOT NULL DEFAULT 'confirmada',
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
  descuento DECIMAL(12,2) NOT NULL DEFAULT 0,
  impuesto DECIMAL(12,2) NOT NULL DEFAULT 0,
  total DECIMAL(12,2) NOT NULL DEFAULT 0,
  observacion VARCHAR(500) NULL,
  anulada_por BIGINT UNSIGNED NULL,
  anulada_en DATETIME NULL,
  motivo_anulacion VARCHAR(255) NULL,
  FOREIGN KEY (cliente_id) REFERENCES clientes(id),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (anulada_por) REFERENCES usuarios(id),
  CONSTRAINT chk_venta_importes CHECK (
    subtotal >= 0 AND descuento >= 0 AND impuesto >= 0 AND total >= 0
  ),
  INDEX idx_venta_fecha (fecha),
  INDEX idx_venta_estado (estado)
) ENGINE=InnoDB;
CREATE TABLE detalle_venta (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  venta_id BIGINT UNSIGNED NOT NULL,
  producto_id BIGINT UNSIGNED NOT NULL,
  cantidad INT NOT NULL,
  precio_unitario DECIMAL(12,2) NOT NULL,
  descuento DECIMAL(12,2) NOT NULL DEFAULT 0,
  subtotal DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (venta_id) REFERENCES ventas(id),
  FOREIGN KEY (producto_id) REFERENCES productos(id),
  CONSTRAINT chk_det_venta_cantidad CHECK (cantidad > 0),
  CONSTRAINT chk_det_venta_importes CHECK (
    precio_unitario >= 0 AND descuento >= 0 AND subtotal >= 0
  ),
  INDEX idx_det_venta_producto (producto_id)
) ENGINE=InnoDB;
CREATE TABLE movimientos_stock (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  producto_id BIGINT UNSIGNED NOT NULL,
  usuario_id BIGINT UNSIGNED NOT NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  tipo ENUM('compra','venta','ajuste_entrada','ajuste_salida','anulacion_compra','anulacion_venta') NOT NULL,
  cantidad INT NOT NULL,
  stock_anterior INT NOT NULL,
  stock_nuevo INT NOT NULL,
  referencia_tipo VARCHAR(30) NULL,
  referencia_id BIGINT UNSIGNED NULL,
  motivo VARCHAR(255) NULL,
  FOREIGN KEY (producto_id) REFERENCES productos(id),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  CONSTRAINT chk_mov_cantidad CHECK (cantidad > 0),
  CONSTRAINT chk_mov_stock CHECK (stock_anterior >= 0 AND stock_nuevo >= 0),
  INDEX idx_mov_producto_fecha (producto_id, fecha)
) ENGINE=InnoDB;

CREATE TABLE auditoria (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id BIGINT UNSIGNED NULL,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  accion VARCHAR(60) NOT NULL,
  tabla_afectada VARCHAR(60) NOT NULL,
  registro_id BIGINT UNSIGNED NULL,
  detalle VARCHAR(500) NULL,
  ip VARCHAR(45) NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  INDEX idx_auditoria_fecha (fecha),
  INDEX idx_auditoria_usuario (usuario_id)
) ENGINE=InnoDB;


-- =========================================================
-- DATOS DE DEMOSTRACIÓN PARA CLASE
-- Usuario inicial: admin | Contraseña: 123
-- Hash generado con PHP password_hash('123', PASSWORD_DEFAULT)
-- =========================================================

INSERT INTO usuarios (nombre, usuario, password_hash, rol, activo) VALUES
('Administrador del sistema', 'admin', '$2y$12$huLUmlhyeSFsMBmt.QA1i.9kCpOwthXRZvIug//a.ApYaXKgXosFi', 'admin', 1);

INSERT INTO unidades_medida (nombre, abreviatura, activo) VALUES
('Unidad', 'UND', 1),
('Paquete', 'PQT', 1),
('Caja', 'CJ', 1),
('Metro', 'M', 1),
('Litro', 'L', 1),
('Kilogramo', 'KG', 1);

INSERT INTO categorias (nombre, descripcion, activo) VALUES
('Computadoras', 'Equipos y componentes informáticos', 1),
('Periféricos', 'Dispositivos complementarios', 1),
('Almacenamiento', 'Discos, memorias y unidades de almacenamiento', 1),
('Cables y adaptadores', 'Cables y accesorios de conexión', 1),
('Accesorios', 'Accesorios de oficina y tecnología', 1),
('General', 'Productos de uso general', 1);

INSERT INTO clientes (tipo_documento, numero_documento, nombre, telefono, correo, direccion, activo) VALUES
('RUC','20601234561','Comercial Andina S.A.C.','01-555-0101','compras@comercialandina.example','Av. Arequipa 1250, Lima',1),
('DNI','45871236','María Fernanda Torres','987654321','maria.torres@example.com','Los Olivos, Lima',1),
('RUC','20509876543','Servicios Integrales del Perú S.R.L.','01-555-0102','logistica@serviciosintegrales.example','San Isidro, Lima',1),
('DNI','71452368','José Luis Mendoza','986123456','j.mendoza@example.com','Comas, Lima',1),
('RUC','20604567891','Soluciones Digitales E.I.R.L.','01-555-0103','administracion@solucionesdigitales.example','Miraflores, Lima',1),
('DNI','43218765','Ana Lucía Rojas','985456123','ana.rojas@example.com','San Miguel, Lima',1),
('RUC','20456789123','Oficinas Modernas S.A.C.','01-555-0104','ventas@oficinasmodernas.example','La Victoria, Lima',1),
('DNI','76543218','Carlos Alberto Vega','984321654','c.vega@example.com','Independencia, Lima',1);

INSERT INTO proveedores (tipo_documento, numero_documento, nombre, contacto, telefono, correo, direccion, activo) VALUES
('RUC','20123456789','Distribuidora Tecnológica S.A.C.','Luis Paredes','01-555-1001','pedidos@distrotec.example','Cercado de Lima, Lima',1),
('RUC','20543219876','Importaciones Globales E.I.R.L.','Rosa Salazar','01-555-1002','ventas@importglobal.example','La Victoria, Lima',1),
('RUC','20607891234','Periféricos del Centro S.R.L.','Miguel Huamán','01-555-1003','contacto@perifericos.example','Breña, Lima',1),
('RUC','20432198765','Almacenes Digitales S.A.C.','Patricia León','01-555-1004','compras@almacenesdigitales.example','San Luis, Lima',1),
('RUC','20609871234','Cables y Conexiones Perú S.A.C.','Diego Flores','01-555-1005','pedidos@cablesconexiones.example','Ate, Lima',1);

INSERT INTO productos
(codigo, nombre, descripcion, categoria_id, unidad_id, precio_compra, precio_venta, stock, stock_minimo, activo) VALUES
('TEC-001','Mouse óptico USB','Mouse óptico con conexión USB',2,1,18.00,29.90,0,5,1),
('TEC-002','Teclado USB español','Teclado en español, conexión USB',2,1,32.00,49.90,0,5,1),
('TEC-003','Memoria USB 64 GB','Memoria portátil USB de 64 GB',3,1,22.00,35.00,0,8,1),
('TEC-004','Cable HDMI 2 m','Cable HDMI de alta velocidad',4,1,9.00,16.90,0,8,1),
('TEC-005','Audífonos con micrófono','Audífonos para videollamadas',2,1,45.00,69.90,0,4,1),
('TEC-006','Webcam HD','Cámara web para reuniones',2,1,78.00,119.00,0,3,1),
('TEC-007','Soporte para laptop','Soporte ajustable para portátil',5,1,38.00,59.90,0,4,1),
('TEC-008','SSD 500 GB','Unidad de estado sólido de 500 GB',3,1,145.00,199.00,0,3,1),
('TEC-009','Mouse pad','Alfombrilla para mouse',5,1,7.00,14.90,0,10,1),
('TEC-010','Monitor 24 pulgadas','Monitor LED Full HD de 24 pulgadas',1,1,430.00,549.00,0,2,1),
('TEC-011','Adaptador USB-C','Adaptador multipuerto USB-C',4,1,42.00,69.00,0,4,1),
('TEC-012','Memoria RAM 16 GB','Módulo de memoria RAM 16 GB',1,1,95.00,139.00,0,3,1);


INSERT INTO compras (numero, proveedor_id, usuario_id, fecha, estado, subtotal, impuesto, total, observacion) VALUES ('COM-DEMO-001', 1, 1, '2026-09-28 10:15:00', 'confirmada', 2020.00, 0.00, 2020.00, 'Compra de demostración para prácticas');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (1, 1, 20, 18.00, 360.00);
UPDATE productos SET stock=20 WHERE id=1;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (1, 1, '2026-09-28 10:15:00', 'compra', 20, 0, 20, 'compras', 1, 'Compra de demostración COM-DEMO-001');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (1, 2, 15, 32.00, 480.00);
UPDATE productos SET stock=15 WHERE id=2;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (2, 1, '2026-09-28 10:15:00', 'compra', 15, 0, 15, 'compras', 1, 'Compra de demostración COM-DEMO-001');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (1, 3, 25, 22.00, 550.00);
UPDATE productos SET stock=25 WHERE id=3;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (3, 1, '2026-09-28 10:15:00', 'compra', 25, 0, 25, 'compras', 1, 'Compra de demostración COM-DEMO-001');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (1, 4, 20, 9.00, 180.00);
UPDATE productos SET stock=20 WHERE id=4;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (4, 1, '2026-09-28 10:15:00', 'compra', 20, 0, 20, 'compras', 1, 'Compra de demostración COM-DEMO-001');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (1, 5, 10, 45.00, 450.00);
UPDATE productos SET stock=10 WHERE id=5;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (5, 1, '2026-09-28 10:15:00', 'compra', 10, 0, 10, 'compras', 1, 'Compra de demostración COM-DEMO-001');
INSERT INTO compras (numero, proveedor_id, usuario_id, fecha, estado, subtotal, impuesto, total, observacion) VALUES ('COM-DEMO-002', 2, 1, '2026-10-03 11:20:00', 'confirmada', 2084.00, 0.00, 2084.00, 'Compra de demostración para prácticas');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (2, 6, 8, 78.00, 624.00);
UPDATE productos SET stock=8 WHERE id=6;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (6, 1, '2026-10-03 11:20:00', 'compra', 8, 0, 8, 'compras', 2, 'Compra de demostración COM-DEMO-002');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (2, 7, 10, 38.00, 380.00);
UPDATE productos SET stock=10 WHERE id=7;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (7, 1, '2026-10-03 11:20:00', 'compra', 10, 0, 10, 'compras', 2, 'Compra de demostración COM-DEMO-002');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (2, 8, 6, 145.00, 870.00);
UPDATE productos SET stock=6 WHERE id=8;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (8, 1, '2026-10-03 11:20:00', 'compra', 6, 0, 6, 'compras', 2, 'Compra de demostración COM-DEMO-002');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (2, 9, 30, 7.00, 210.00);
UPDATE productos SET stock=30 WHERE id=9;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (9, 1, '2026-10-03 11:20:00', 'compra', 30, 0, 30, 'compras', 2, 'Compra de demostración COM-DEMO-002');
INSERT INTO compras (numero, proveedor_id, usuario_id, fecha, estado, subtotal, impuesto, total, observacion) VALUES ('COM-DEMO-003', 3, 1, '2026-10-08 09:40:00', 'confirmada', 4114.00, 0.00, 4114.00, 'Compra de demostración para prácticas');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (3, 10, 5, 430.00, 2150.00);
UPDATE productos SET stock=5 WHERE id=10;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (10, 1, '2026-10-08 09:40:00', 'compra', 5, 0, 5, 'compras', 3, 'Compra de demostración COM-DEMO-003');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (3, 11, 12, 42.00, 504.00);
UPDATE productos SET stock=12 WHERE id=11;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (11, 1, '2026-10-08 09:40:00', 'compra', 12, 0, 12, 'compras', 3, 'Compra de demostración COM-DEMO-003');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (3, 12, 10, 95.00, 950.00);
UPDATE productos SET stock=10 WHERE id=12;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (12, 1, '2026-10-08 09:40:00', 'compra', 10, 0, 10, 'compras', 3, 'Compra de demostración COM-DEMO-003');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (3, 1, 10, 18.00, 180.00);
UPDATE productos SET stock=30 WHERE id=1;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (1, 1, '2026-10-08 09:40:00', 'compra', 10, 20, 30, 'compras', 3, 'Compra de demostración COM-DEMO-003');
INSERT INTO detalle_compra (compra_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (3, 3, 15, 22.00, 330.00);
UPDATE productos SET stock=40 WHERE id=3;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (3, 1, '2026-10-08 09:40:00', 'compra', 15, 25, 40, 'compras', 3, 'Compra de demostración COM-DEMO-003');
INSERT INTO ventas (numero, cliente_id, usuario_id, fecha, estado, subtotal, descuento, impuesto, total, observacion) VALUES ('VTA-DEMO-001', 1, 1, '2026-10-10 12:10:00', 'confirmada', 445.10, 0.00, 0.00, 445.10, 'Venta de demostración para prácticas');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (1, 1, 4, 29.90, 0.00, 119.60);
UPDATE productos SET stock=26 WHERE id=1;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (1, 1, '2026-10-10 12:10:00', 'venta', 4, 30, 26, 'ventas', 1, 'Venta de demostración VTA-DEMO-001');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (1, 2, 2, 49.90, 0.00, 99.80);
UPDATE productos SET stock=13 WHERE id=2;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (2, 1, '2026-10-10 12:10:00', 'venta', 2, 15, 13, 'ventas', 1, 'Venta de demostración VTA-DEMO-001');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (1, 3, 5, 35.00, 0.00, 175.00);
UPDATE productos SET stock=35 WHERE id=3;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (3, 1, '2026-10-10 12:10:00', 'venta', 5, 40, 35, 'ventas', 1, 'Venta de demostración VTA-DEMO-001');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (1, 4, 3, 16.90, 0.00, 50.70);
UPDATE productos SET stock=17 WHERE id=4;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (4, 1, '2026-10-10 12:10:00', 'venta', 3, 20, 17, 'ventas', 1, 'Venta de demostración VTA-DEMO-001');
INSERT INTO ventas (numero, cliente_id, usuario_id, fecha, estado, subtotal, descuento, impuesto, total, observacion) VALUES ('VTA-DEMO-002', 2, 1, '2026-10-12 15:35:00', 'confirmada', 497.80, 0.00, 0.00, 497.80, 'Venta de demostración para prácticas');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (2, 5, 2, 69.90, 0.00, 139.80);
UPDATE productos SET stock=8 WHERE id=5;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (5, 1, '2026-10-12 15:35:00', 'venta', 2, 10, 8, 'ventas', 2, 'Venta de demostración VTA-DEMO-002');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (2, 6, 1, 119.00, 0.00, 119.00);
UPDATE productos SET stock=7 WHERE id=6;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (6, 1, '2026-10-12 15:35:00', 'venta', 1, 8, 7, 'ventas', 2, 'Venta de demostración VTA-DEMO-002');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (2, 7, 2, 59.90, 0.00, 119.80);
UPDATE productos SET stock=8 WHERE id=7;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (7, 1, '2026-10-12 15:35:00', 'venta', 2, 10, 8, 'ventas', 2, 'Venta de demostración VTA-DEMO-002');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (2, 9, 8, 14.90, 0.00, 119.20);
UPDATE productos SET stock=22 WHERE id=9;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (9, 1, '2026-10-12 15:35:00', 'venta', 8, 30, 22, 'ventas', 2, 'Venta de demostración VTA-DEMO-002');
INSERT INTO ventas (numero, cliente_id, usuario_id, fecha, estado, subtotal, descuento, impuesto, total, observacion) VALUES ('VTA-DEMO-003', 3, 1, '2026-10-15 16:05:00', 'confirmada', 1164.00, 0.00, 0.00, 1164.00, 'Venta de demostración para prácticas');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (3, 8, 1, 199.00, 0.00, 199.00);
UPDATE productos SET stock=5 WHERE id=8;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (8, 1, '2026-10-15 16:05:00', 'venta', 1, 6, 5, 'ventas', 3, 'Venta de demostración VTA-DEMO-003');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (3, 10, 1, 549.00, 0.00, 549.00);
UPDATE productos SET stock=4 WHERE id=10;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (10, 1, '2026-10-15 16:05:00', 'venta', 1, 5, 4, 'ventas', 3, 'Venta de demostración VTA-DEMO-003');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (3, 11, 2, 69.00, 0.00, 138.00);
UPDATE productos SET stock=10 WHERE id=11;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (11, 1, '2026-10-15 16:05:00', 'venta', 2, 12, 10, 'ventas', 3, 'Venta de demostración VTA-DEMO-003');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (3, 12, 2, 139.00, 0.00, 278.00);
UPDATE productos SET stock=8 WHERE id=12;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (12, 1, '2026-10-15 16:05:00', 'venta', 2, 10, 8, 'ventas', 3, 'Venta de demostración VTA-DEMO-003');
INSERT INTO ventas (numero, cliente_id, usuario_id, fecha, estado, subtotal, descuento, impuesto, total, observacion) VALUES ('VTA-DEMO-004', 4, 1, '2026-10-18 10:25:00', 'confirmada', 472.60, 0.00, 0.00, 472.60, 'Venta de demostración para prácticas');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (4, 1, 3, 29.90, 0.00, 89.70);
UPDATE productos SET stock=23 WHERE id=1;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (1, 1, '2026-10-18 10:25:00', 'venta', 3, 26, 23, 'ventas', 4, 'Venta de demostración VTA-DEMO-004');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (4, 3, 4, 35.00, 0.00, 140.00);
UPDATE productos SET stock=31 WHERE id=3;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (3, 1, '2026-10-18 10:25:00', 'venta', 4, 35, 31, 'ventas', 4, 'Venta de demostración VTA-DEMO-004');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (4, 4, 5, 16.90, 0.00, 84.50);
UPDATE productos SET stock=12 WHERE id=4;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (4, 1, '2026-10-18 10:25:00', 'venta', 5, 17, 12, 'ventas', 4, 'Venta de demostración VTA-DEMO-004');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (4, 9, 6, 14.90, 0.00, 89.40);
UPDATE productos SET stock=16 WHERE id=9;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (9, 1, '2026-10-18 10:25:00', 'venta', 6, 22, 16, 'ventas', 4, 'Venta de demostración VTA-DEMO-004');
INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario, descuento, subtotal) VALUES (4, 11, 1, 69.00, 0.00, 69.00);
UPDATE productos SET stock=9 WHERE id=11;
INSERT INTO movimientos_stock (producto_id, usuario_id, fecha, tipo, cantidad, stock_anterior, stock_nuevo, referencia_tipo, referencia_id, motivo) VALUES (11, 1, '2026-10-18 10:25:00', 'venta', 1, 10, 9, 'ventas', 4, 'Venta de demostración VTA-DEMO-004');
INSERT INTO auditoria (usuario_id, fecha, accion, tabla_afectada, registro_id, detalle, ip) VALUES
(1,'2026-10-18 10:25:00','LOGIN','usuarios',1,'Inicio de sesión de demostración','127.0.0.1'),
(1,'2026-10-18 10:26:00','CREAR','productos',1,'Catálogo de productos de demostración cargado','127.0.0.1'),
(1,'2026-10-18 10:27:00','CREAR','compras',1,'Compras de ejemplo cargadas para prácticas','127.0.0.1'),
(1,'2026-10-18 10:28:00','CREAR','ventas',1,'Ventas de ejemplo cargadas para prácticas','127.0.0.1');

-- Inventario final de demostración:
-- Mouse óptico USB=23, Teclado USB español=13, Memoria USB 64 GB=31, Cable HDMI 2 m=12, Audífonos con micrófono=8, Webcam HD=7, Soporte para laptop=8, SSD 500 GB=5, Mouse pad=16, Monitor 24 pulgadas=4, Adaptador USB-C=9, Memoria RAM 16 GB=8

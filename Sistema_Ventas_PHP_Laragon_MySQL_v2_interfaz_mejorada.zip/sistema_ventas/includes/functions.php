<?php
if (session_status() !== PHP_SESSION_ACTIVE) { session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS']),'samesite'=>'Lax']); session_start(); }
require_once __DIR__ . '/../config/database.php';
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $page, array $params=[]): string { return 'index.php?' . http_build_query(['page'=>$page]+$params); }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">'; }
function check_csrf(): void { if ($_SERVER['REQUEST_METHOD']==='POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('La sesión del formulario expiró. Regresa e inténtalo de nuevo.'); } }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_login(): void { if (!current_user()) { header('Location: index.php?page=login'); exit; } }
function require_admin(): void { require_login(); if (current_user()['rol']!=='admin') { http_response_code(403); exit('No tienes permisos para acceder a esta sección.'); } }
function flash(string $message, string $type='success'): void { $_SESSION['flash']=['message'=>$message,'type'=>$type]; }
function audit(string $action, string $table, ?int $id=null, string $detail=''): void { try { $q=db()->prepare('INSERT INTO auditoria(usuario_id,accion,tabla_afectada,registro_id,detalle,ip) VALUES(?,?,?,?,?,?)'); $q->execute([current_user()['id'] ?? null,$action,$table,$id,mb_substr($detail,0,500),substr($_SERVER['REMOTE_ADDR'] ?? '',0,45)]); } catch(Throwable $e) {} }
function go(string $page, array $params=[]): never { header('Location: '.url($page,$params)); exit; }
function money($v): string { return 'S/ '.number_format((float)$v,2); }
function active_options(string $table): array { return db()->query("SELECT id,nombre FROM {$table} WHERE activo=1 ORDER BY nombre")->fetchAll(); }
function postv(string $key, $default='') { return trim((string)($_POST[$key] ?? $default)); }
check_csrf();
